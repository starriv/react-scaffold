import React, {Component} from 'react';
import './app.less';
class App extends Component {
  render() {
    return (
      <p className="hello">Hello React</p>
    )
  }
}

export default App;
