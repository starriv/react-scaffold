import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/app/app';

const node = document.getElementById('app');
ReactDOM.render(<App name="React"/>, node);
